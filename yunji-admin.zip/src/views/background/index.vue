<template>
  <div id="background">
    背景图管理
  </div>
</template>

<script>
export default {
  name: 'background',
  components: {}
}
</script>

<style lang="scss">
#background {

}
</style>
