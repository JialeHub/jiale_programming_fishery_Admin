<template>
  <div id="partner">
    合作伙伴管理
  </div>
</template>

<script>
export default {
  name: 'partner',
  components: {}
}
</script>

<style lang="scss">
#partner {

}
</style>
