<template>
  <div id="case">
    案例展示管理
  </div>
</template>

<script>
export default {
  name: 'case',
  components: {}
}
</script>

<style lang="scss">
#case {

}
</style>
