<template>
  <div id="dynamic">
    公司动态管理
  </div>
</template>

<script>
export default {
  name: 'dynamic',
  components: {}
}
</script>

<style lang="scss">
#dynamic {

}
</style>
