<template>
  <div id="about">
    关于我们
  </div>
</template>

<script>
export default {
  name: 'about',
  components: {}
}
</script>

<style lang="scss">
#about {

}
</style>
