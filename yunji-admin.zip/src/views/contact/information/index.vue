<template>
  <div id="information">
    联系方式
  </div>
</template>

<script>
export default {
  name: 'information',
  components: {}
}
</script>

<style lang="scss">
#information {

}
</style>
