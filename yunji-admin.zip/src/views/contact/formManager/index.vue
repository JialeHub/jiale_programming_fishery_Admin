<template>
  <div id="formManager">
    表单管理
  </div>
</template>

<script>
export default {
  name: 'formManager',
  components: {}
}
</script>

<style lang="scss">
#formManager {

}
</style>
