<template>
  <div id="audit">
    表单审核
  </div>
</template>

<script>
export default {
  name: 'audit',
  components: {}
}
</script>

<style lang="scss">
#audit {

}
</style>
